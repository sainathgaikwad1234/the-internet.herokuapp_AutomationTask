import { test, expect } from '@playwright/test';

test('Appointment Scheduling – Mandatory Fields', async ({ page }) => {
  // 1. Go to the login page
  await page.goto('https://stage_ketamin.uat.provider.ecarehealth.com/');

  // 2. Login
  await page.getByPlaceholder('Email').fill('amol.shete+TP@medarch.com');
  await page.getByPlaceholder('*********').fill('Test@123$');
  await page.getByRole('button', { name: "Let's get Started" }).click();

  // 3. Wait for dashboard to load
  await page.getByText('Create', { exact: true }).waitFor();

  // 4. Click "Create" > "New appointment."
  await page.getByText('Create', { exact: true }).click();
  await page.getByText('New Appointment', { exact: true }).click();

  // 5. Select “Patient name” from the dropdown - Sainath Gaikwad (search and select)
  await page.getByRole('combobox', { name: 'Patient Name *' }).click();
  await page.getByRole('combobox', { name: 'Patient Name *' }).fill('Sainath Gaikwad');
  await page.getByRole('option', { name: 'Sainath Gaikwad' }).click();

  // 6. Select “Appointment type.” from the dropdown - New Patient Visit
  await page.getByRole('combobox', { name: 'Appointment Type *' }).click();
  await page.getByRole('option', { name: 'New Patient Visit' }).click();

  // 7. Fill “Reason for visit” textfield - Fever
  await page.getByRole('textbox', { name: 'Reason For Visit *' }).fill('Fever');

  // 8. Select “Time zone” from the dropdown - Alaska Standard Time (GMT -09:00)
  await page.getByRole('combobox', { name: 'Timezone *' }).click();
  await page.getByRole('option', { name: 'Alaska Standard Time (GMT -09:00)' }).click();

  // 9. Select “Visit type” from the toggle button - Telehealth
  await page.getByRole('button', { name: 'Telehealth' }).click();

  // 10. Select “Provider” from the dropdown - Andrew Ross
  await page.getByRole('combobox', { name: 'Provider *' }).click();
  await page.getByRole('option', { name: 'Andrew Ross' }).click();

  // 11. Click on “View Availability” button
  await page.getByRole('button', { name: /View availability/i }).click();

  // Wait for the calendar modal/dialog to be visible
  const calendarModal = page.locator('[role="dialog"]');
  await calendarModal.waitFor({ state: 'visible', timeout: 10000 });

  // Debug: Print all gridcell texts inside the modal for troubleshooting
  const modalDateCells = await calendarModal.locator('[role="gridcell"]').allTextContents();
  console.log('Modal gridcell texts:', modalDateCells);

  // Print all visible elements in the modal that contain AM or PM in their text for debugging
  const allModalElements = await calendarModal.locator('*').elementHandles();
  for (const el of allModalElements) {
    const text = await el.evaluate(node => node.textContent?.trim());
    if (text && /AM|PM/.test(text) && await el.isVisible()) {
      console.log('Visible modal element with time:', text);
    }
  }

  // Click the first visible cell with exact text '8' inside the modal
  const dateCells = await calendarModal.locator('[role="gridcell"]').elementHandles();
  for (const cell of dateCells) {
    const text = await cell.evaluate(node => node.textContent?.trim());
    if (text === '8' && await cell.isVisible()) {
      await cell.click();
      break;
    }
  }

  // After clicking the date, add a longer wait for time slots to load
  await page.waitForTimeout(3000); // Wait 3 seconds for slots to render

  // Print the full HTML of the page after clicking the date for debugging
  const pageHtml = await page.content();
  console.log('PAGE_HTML_START');
  console.log(pageHtml);
  console.log('PAGE_HTML_END');

  // Print all visible button texts for debugging
  const allButtons = await page.locator('button').elementHandles();
  for (const btn of allButtons) {
    const text = await btn.evaluate(node => node.textContent?.trim());
    if (text && await btn.isVisible()) {
      console.log('Visible button:', text);
    }
  }

  // Print all visible elements with a time range in their text for debugging
  const allElements = await page.locator('*').elementHandles();
  for (const el of allElements) {
    const text = await el.evaluate(node => node.textContent?.trim());
    if (text && /\d{2}:\d{2} (AM|PM) - \d{2}:\d{2} (AM|PM)/.test(text) && await el.isVisible()) {
      console.log('Visible element with time slot:', text);
    }
  }

  // Try to click the first visible element with a time range
  let slotClicked = false;
  for (const el of allElements) {
    const text = await el.evaluate(node => node.textContent?.trim());
    if (text && /\d{2}:\d{2} (AM|PM) - \d{2}:\d{2} (AM|PM)/.test(text) && await el.isVisible()) {
      console.log('Clicking visible element with time slot:', text);
      await el.scrollIntoViewIfNeeded();
      await el.click({ force: true });
      slotClicked = true;
      break;
    }
  }
  if (!slotClicked) {
    throw new Error('No available visible time slot element found!');
  }

  // 13. After selecting the time slot, click on Save and close.
  await page.getByRole('button', { name: /Save And Close/i }).click();

  // 14. Click on the Scheduling in task bar (first visible)
  const schedulingTabs = await page.getByText('Scheduling', { exact: true }).elementHandles();
  for (const tab of schedulingTabs) {
    if (await tab.isVisible()) {
      await tab.click();
      break;
    }
  }

  // 15. Click on the “Appointments”
  await page.getByText('Appointments', { exact: true }).click();

  // 16. Check if a new appointment is created or not (look for patient name, first visible occurrence)
  await expect(page.getByText('Sainath Gaikwad').first()).toBeVisible({ timeout: 10000 });
});
